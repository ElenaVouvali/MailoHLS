import torch
try:
    from torch_scatter import scatter_add
except ImportError:
    # Modern PyG supports native PyTorch scatter; preserve the historical API.
    from torch_geometric.utils import scatter as _scatter
    def scatter_add(src, index, dim=0, dim_size=None):
        return _scatter(src, index, dim=dim, dim_size=dim_size, reduce='sum')
from torch_geometric.utils import softmax

from torch_geometric.nn.inits import reset


class MyGlobalAttention(torch.nn.Module):
    r"""Global soft attention layer from the `"Gated Graph Sequence Neural
    Networks" <https://arxiv.org/abs/1511.05493>`_ paper

    .. math::
        \mathbf{r}_i = \sum_{n=1}^{N_i} \mathrm{softmax} \left(
        h_{\mathrm{gate}} ( \mathbf{x}_n ) \right) \odot
        h_{\mathbf{\Theta}} ( \mathbf{x}_n ),

    where :math:`h_{\mathrm{gate}} \colon \mathbb{R}^F \to
    \mathbb{R}` and :math:`h_{\mathbf{\Theta}}` denote neural networks, *i.e.*
    MLPS.

    Args:
        gate_nn (torch.nn.Module): A neural network :math:`h_{\mathrm{gate}}`
            that computes attention scores by mapping node features :obj:`x` of
            shape :obj:`[-1, in_channels]` to shape :obj:`[-1, 1]`, *e.g.*,
            defined by :class:`torch.nn.Sequential`.
        nn (torch.nn.Module, optional): A neural network
            :math:`h_{\mathbf{\Theta}}` that maps node features :obj:`x` of
            shape :obj:`[-1, in_channels]` to shape :obj:`[-1, out_channels]`
            before combining them with the attention scores, *e.g.*, defined by
            :class:`torch.nn.Sequential`. (default: :obj:`None`)
    """
    def __init__(self, gate_nn, nn=None):
        super(MyGlobalAttention, self).__init__()
        self.gate_nn = gate_nn
        self.nn = nn

        self.reset_parameters()

    def reset_parameters(self):
        reset(self.gate_nn)
        reset(self.nn)

    def forward(self, x, batch, set_zeros_ids=None, size=None):
        x = x.unsqueeze(-1) if x.dim() == 1 else x
        size = int(batch.max()) + 1 if size is None else size

        logits = self.gate_nn(x).view(-1)
        x = self.nn(x) if self.nn is not None else x

        if set_zeros_ids is not None:
            mask = set_zeros_ids.reshape(-1).bool()
            selected = scatter_add(
                mask.long(), batch, dim=0, dim_size=size
            )
            if torch.any(selected == 0):
                raise RuntimeError(
                    "Masked attention received a graph with no selected nodes."
                )
            logits = logits.masked_fill(~mask, -torch.inf)

        gate = softmax(logits, batch, num_nodes=size).view(-1, 1)
        out = scatter_add(gate * x, batch, dim=0, dim_size=size)
        return out, gate

    def __repr__(self):
        return '{}(gate_nn={}, nn={})'.format(self.__class__.__name__,
                                              self.gate_nn, self.nn)
