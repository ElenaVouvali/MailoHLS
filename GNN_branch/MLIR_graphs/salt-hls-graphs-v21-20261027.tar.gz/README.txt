SALT-HLS V2.1: locked 63-snapshot research graph release.
Read release.json for graph filenames, exact input identities, coverage and compiler provenance.
Verify: sha256sum --check checksums.sha256
canonical/ is authoritative; compact/ reconstructs canonical graphs exactly.
Source/header snapshots and raw MLIR are included. All earlier graph versions remain separate.
code/ freezes the builder, query logic and toolchain lock; provenance/ preserves execution receipts.
Rebuild from the repository using the pinned native Python and cgeist: pass each graph's
generation_arguments to python -m GNN_branch.mlir_graph_v2, plus --cgeist, --output and --mlir-output.
Relative source paths are relative to this extracted archive. Output must be a fresh directory.
Original absolute frontend locations remain in raw IR/provenance; relocation can change IR hashes.
JPEG, Rosetta and two prior GEMV variants are excluded, not silently substituted.
This is not a complete external workload corpus or a trained V2.1 GNN.
