"""Package the validated 63-snapshot release without editing older artifacts."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path('/home/elvouvali/MailoHLS')
import sys
sys.path.insert(0,str(ROOT))
from GNN_branch import mlir_graph_v2 as v2
from experiments.structural_audit.compare_v2 import _relations

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write_once(path,data):
    if path.exists() and path.read_bytes()!=data:
        raise ValueError('Refusing to change sealed release file: '+str(path))
    path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
def encoded(data):return (json.dumps(data,sort_keys=True,indent=2)+'\n').encode()

output=ROOT/'GNN_branch/MLIR_graphs/v21_corpus/release_20261027'
m=json.loads((output/'corpus_manifest.json').read_text())
old_path=ROOT/'GNN_branch/MLIR_graphs/v21_corpus/validated/corpus_manifest.json'
assert sha(old_path)==m['parent_manifest_sha256']
old=json.loads(old_path.read_text())
assert len(m['records'])==63 and all(r.get('validation')=='pass' and r.get('reconstruction')=='exact'
    and r.get('semantic_queries')=='identical' for r in m['records'].values())
assert all(sha(Path(p))==h for p,h in m['code_sha256'].items())
files={}
def add(name,path):
    path=Path(path)
    if name in files and sha(files[name])!=sha(path): raise ValueError('Archive path collision: '+name)
    files[name]=path
def facts(g):return {a:[{k:v for k,v in r.items() if k not in ('graph_identity','source_provenance')}
                       for r in rs] for a,rs in _relations(g).items()}
records=[]
for ident,r in sorted(m['records'].items(),key=lambda item:(item[1]['kernel'],item[0])):
    parent=old['records'][ident]
    for kind in ('canonical','compact'):
        assert sha(parent[kind])==parent[kind+'_sha256'], 'Historical graph changed'
        assert sha(r[kind])==r[kind+'_sha256'], 'New graph changed'
    before=v2.read_graph(parent['canonical']);after=v2.read_graph(r['canonical'])
    assert facts(before)==facts(after), 'Compiler facts changed: '+r['kernel']
    assert before.graph['action_point_coverage']==after.graph['action_point_coverage']
    assert after.graph['provenance']['v2_builder_sha256']==sha(ROOT/'GNN_branch/mlir_graph_v2.py')
    compact=v2.read_graph(r['compact'])
    assert v2.graph_payload(v2.expand_compact(compact))==v2.graph_payload(after)
    entry={k:r[k] for k in ('kernel','snapshot_id','top','source_sha256','metadata_sha256',
        'canonical_sha256','compact_sha256','canonical_nodes','canonical_edges','compact_nodes',
        'compact_edges','numerical_fidelity')}
    entry['aliases']=r['aliases']
    entry['coverage']={k:r['coverage'][k] for k in ('registered','compiler_active','compiler_unresolved','source_only')}
    entry['unresolved_action_points']=[x['action_id'] for x in after.graph['action_point_coverage']['records']
        if x['metadata_registered'] and not x['compiler_matched']]
    for kind in ('canonical','compact','raw_mlir'):
        path=Path(r[kind]);assert sha(path)==r[kind+'_sha256']
        entry[kind]=kind+'/'+path.name;add(entry[kind],path)
    for kind in ('source','metadata'):
        path=Path(r[kind]);assert sha(path)==r[kind+'_sha256']
        entry[kind]='source_snapshots/'+ident+'/'+path.name;add(entry[kind],path)
    entry['headers']={}
    for name,digest in r['local_header_sha256'].items():
        path=Path(r['source']).parent/name;assert sha(path)==digest
        target='source_snapshots/'+ident+'/'+name;add(target,path);entry['headers'][target]=digest
    args=r['command']
    entry['generation_arguments']=['--revision','2.1','--source',entry['source'],'--metadata',entry['metadata']]
    if '--compiler-symbol' in args:
        entry['generation_arguments']+=['--compiler-symbol',args[args.index('--compiler-symbol')+1]]
    entry['parent_compiler_facts']='identical; generation provenance checked separately'
    records.append(entry)
    print('Checked',r['kernel'],flush=True)

code={p:sha(ROOT/p) for p in ('GNN_branch/mlir_graph_v2.py','GNN_branch/mlir_graph_gen.py',
    'GNN_branch/mlir_semantics.py','GNN_branch/action_point_relations.py','tests/test_mlir_graph_v2.py',
    'toolchain/lock.env')}
for path in code:add('code/'+path,ROOT/path)
add('provenance/published_corpus_driver.py',output/'provenance/generate_mlir_v2_corpus.py')
add('provenance/regenerate_locked_inventory.py','/tmp/mailohls_seal_graphs.py')
add('provenance/package_release.py',__file__)
add('provenance/generation_manifest.json',output/'corpus_manifest.json')

content=dict(release_id=m['release'],schema=v2.SCHEMA_V21,status='sealed',
    baseline_git_commit='6863ce08e3a98e64c44e48a1f4b9245054236a95',
    compiler=m['toolchain'],code_sha256=code,parent_manifest_sha256=m['parent_manifest_sha256'],
    graph_count=len(records),development_kernel_count=55,external_snapshot_count=8,
    registered_action_points=sum(r['coverage']['registered'] for r in records),
    compiler_active_action_points=sum(r['coverage']['compiler_active'] for r in records),
    unresolved_action_points=sum(r['coverage']['compiler_unresolved'] for r in records),
    canonical_compact_equivalence='63/63 exact reconstruction and identical public semantic queries',
    comparison='63/63 identical parent compiler facts and action coverage; builder/raw-IR provenance differs and is retained',
    excluded=[dict(kernel=r['kernel'],metadata=str(Path(r['metadata']).relative_to(ROOT)),
        reason='Outside approved 63-snapshot release; prior frontend or source/action-metadata blocker') for r in m['excluded_snapshots']],
    limitations=['No V2.1 tensor encoder or trained GNN; incompatible with V1 weights',
        'Numerical analysis headers may be simplified; see per-snapshot fidelity',
        'Transitive system include closure is not fully sealed',
        'Source-reference annotations remain unreviewed drafts',
        'No new HLS or functional-equivalence measurements in this release'],
    graphs=records,files_sha256={name:sha(path) for name,path in sorted(files.items())})
portable=output/'release.json';write_once(portable,encoded(content));add('release.json',portable)
readme=output/'README-release.txt'
write_once(readme,b'''SALT-HLS V2.1: locked 63-snapshot research graph release.
Read release.json for graph filenames, exact input identities, coverage and compiler provenance.
Verify: sha256sum --check checksums.sha256
canonical/ is authoritative; compact/ reconstructs canonical graphs exactly.
Source/header snapshots and raw MLIR are included. All earlier graph versions remain separate.
code/ freezes the builder, query logic and toolchain lock; provenance/ preserves execution receipts.
Rebuild from the repository using the pinned native Python and cgeist: pass each graph's
generation_arguments to python -m GNN_branch.mlir_graph_v2, plus --cgeist, --output and --mlir-output.
Relative source paths are relative to this extracted archive. Output must be a fresh directory.
Original absolute frontend locations remain in raw IR/provenance; relocation can change IR hashes.
JPEG, Rosetta and two prior GEMV variants are excluded, not silently substituted.
This is not a complete external workload corpus or a trained V2.1 GNN.
''');add('README.txt',readme)
checksums=output/'checksums.sha256'
write_once(checksums,''.join(sha(path)+'  '+name+'\n' for name,path in sorted(files.items())).encode())
add('checksums.sha256',checksums)
archive=ROOT/'GNN_branch/MLIR_graphs/salt-hls-graphs-v21-20261027.tar.gz'
temporary=archive.with_suffix('.tmp')
with temporary.open('wb') as stream,gzip.GzipFile(fileobj=stream,mode='wb',filename='',mtime=0,compresslevel=9) as compressed:
    with tarfile.open(fileobj=compressed,mode='w') as bundle:
        for name,path in sorted(files.items()):
            info=tarfile.TarInfo(name);info.size=path.stat().st_size;info.mode=0o644
            with path.open('rb') as handle:bundle.addfile(info,handle)
if archive.exists():
    assert sha(archive)==sha(temporary),'Refusing to replace sealed archive'
    temporary.unlink()
else:temporary.replace(archive)
public={**content,'archive':str(archive.relative_to(ROOT)),'archive_sha256':sha(archive),
    'archive_bytes':archive.stat().st_size,'content_manifest_sha256':sha(portable)}
lock=ROOT/'docs/graph-release-v21.json';write_once(lock,encoded(public))
checksum=ROOT/'docs/graph-release-v21.sha256'
write_once(checksum,(sha(archive)+'  '+str(archive.relative_to(ROOT))+'\n'+sha(lock)+'  '+str(lock.relative_to(ROOT))+'\n').encode())
print('SEALED',len(records),'graphs;',archive.stat().st_size,'bytes; SHA256',sha(archive),flush=True)
