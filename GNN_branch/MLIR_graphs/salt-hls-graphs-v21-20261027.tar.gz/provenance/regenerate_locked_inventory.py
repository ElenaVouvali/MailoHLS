"""Freeze the approved 63-snapshot inventory; delegate all graph work."""
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path('/home/elvouvali/MailoHLS')
sys.path.insert(0, str(ROOT))
from experiments.refinement import configurations as c
from GNN_branch import mlir_graph_v2 as v2
from experiments.structural_audit.compare_v2 import _relations

spec = importlib.util.spec_from_file_location('published_corpus_driver', '/tmp/mailohls_release_corpus_driver.py')
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)
old_path = ROOT/'GNN_branch/MLIR_graphs/v21_corpus/validated/corpus_manifest.json'
old = json.loads(old_path.read_text())
output = ROOT/'GNN_branch/MLIR_graphs/v21_corpus/release_20261027'
output.mkdir(parents=True, exist_ok=True)
driver_copy = output/'provenance/generate_mlir_v2_corpus.py'
driver_copy.parent.mkdir(exist_ok=True)
driver_copy.write_bytes(Path('/tmp/mailohls_release_corpus_driver.py').read_bytes())
tools = driver.compiler_tools(driver.BUILD, str(Path.home()/'.mlir-python311/bin/python'))
assert tools == old['toolchain'], 'Pinned toolchain changed'
snapshots = [r for r in old['inventory']['snapshots'] if old['records'].get(r['snapshot_id'], {}).get('validation') == 'pass']
assert len(snapshots) == 63
excluded = [r for r in old['inventory']['snapshots'] if r not in snapshots]
code = {p:c.sha256(ROOT/p) for p in ('GNN_branch/mlir_graph_v2.py', 'GNN_branch/mlir_graph_gen.py',
    'GNN_branch/mlir_semantics.py', 'GNN_branch/action_point_relations.py')}
code[str(driver_copy.relative_to(ROOT))] = c.sha256(driver_copy)
code[str(Path(__file__))] = c.sha256(__file__)
contract = dict(schema=v2.SCHEMA_V21, release='v21-static-global-fix-20261027',
    parent_manifest_sha256=c.sha256(old_path), code_sha256=code, toolchain=tools,
    inventory={**old['inventory'], 'snapshots':snapshots}, excluded_snapshots=excluded,
    scope='Existing 63 successful snapshots only; JPEG, Rosetta and both GEMV variants excluded')
manifest_path=output/'corpus_manifest.json'
manifest=json.loads(manifest_path.read_text()) if manifest_path.exists() else {**contract,'records':{}}
assert all(manifest[k]==value for k,value in contract.items()), 'Frozen release contract changed'

def facts(graph):
    # Graph identities intentionally change with the patched builder. All
    # compiler facts and query evidence must remain byte-for-byte equivalent.
    return {label:[{k:v for k,v in r.items() if k!='graph_identity'} for r in rows]
            for label,rows in _relations(graph).items()}

for i,snapshot in enumerate(snapshots,1):
    assert c.sha256(snapshot['source'])==snapshot['source_sha256']
    assert c.sha256(snapshot['metadata'])==snapshot['metadata_sha256']
    assert driver.headers(snapshot['source'])==snapshot['local_header_sha256']
    previous=manifest['records'].get(snapshot['snapshot_id'])
    record=driver.process(snapshot,output,tools,previous=previous,timeout=600)
    manifest['records'][snapshot['snapshot_id']]=record
    if record.get('validation')=='pass':
        parent=old['records'][snapshot['snapshot_id']]
        assert c.sha256(parent['canonical'])==parent['canonical_sha256']
        before=v2.read_graph(parent['canonical']);after=v2.read_graph(record['canonical'])
        record['parent_semantic_queries']='identical' if facts(before)==facts(after) else 'changed'
        record['parent_action_coverage']='identical' if before.graph['action_point_coverage']==after.graph['action_point_coverage'] else 'changed'
        record['parent_canonical_sha256']=parent['canonical_sha256']
    temporary=manifest_path.with_suffix('.tmp')
    temporary.write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n');temporary.replace(manifest_path)
    print(f"{i}/63 {snapshot['kernel']}: {record['status']} {record.get('parent_semantic_queries','')} {record.get('error','')[:500]}",flush=True)
    if record.get('validation')!='pass':
        raise RuntimeError('Release blocked: '+record.get('error','unknown failure'))
assert all(c.sha256(Path(p))==digest for p,digest in code.items())
print('63/63 regenerated and validated; ready to seal',flush=True)
