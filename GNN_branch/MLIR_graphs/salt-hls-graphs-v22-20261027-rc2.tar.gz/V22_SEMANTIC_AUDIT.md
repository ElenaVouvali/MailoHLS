# V2.2 semantic audit

V2.2 RELEASE CANDIDATE — remaining evidence required

63/63 snapshots passed mechanical checks; 0 failed; 0 pending.

## Aggregate comparison

| Property | Frozen V2.1 | V2.2 |
|---|---:|---:|
| nodes | 30874 | 30634 |
| edges | 115316 | 115783 |
| registered | 606 | 606 |
| active | 604 | 592 |
| unresolved_registrations | 2 | 14 |
| source_only | 13 | 13 |
| access_status | {'proven': 2813, 'not_established': 182} | {'proven': 2973, 'not_established': 6, 'possible': 32} |
| dependence_status | {'possible': 51659, 'proven': 1911} | {'possible': 51659, 'proven': 1911} |
| dependence_reasons | {'aliased_storage_not_canonicalized': 25454, 'non_affine_access': 6173, 'affine_analysis_failure': 20032} | {'aliased_storage_not_canonicalized': 25454, 'non_affine_access': 6173, 'affine_analysis_failure': 20032} |
| native_negative_conclusions | 150439 | 150439 |
| duplicate_native_queries | 0 | 0 |
| cfg_successors | 0 | 43 |

## Findings and limits

External Kalman L7 has no unique source-bound storage target. L8 was mapped onto the native L6 allocation by shared use lines; V2.2 rejects that mapping. Surviving scalar computations do not prove a separate allocation or compiler elimination.
LLVM GEP/cast/memref-pointer chains retain their base storage and exact index operands. Pointer loads requiring reaching-store/call-context analysis remain uncertain. A root does not establish element overlap.
Pinned Python lacks Operation.successors. V2.2 uses mlirOperationGetSuccessor and checks native CFG occurrences independently.
All native dependence records, positive edges, uncertain edges and negative conclusions are preserved. AES uncertainty is not deduplicated or sampled away. The native analyzer stops at the first successful dependence depth; additional carrying loops remain unverified.
details/ contains comprehensive dependence classifications, root diagnostics, unresolved registrations and deterministic two-per-stratum draft review records. These drafts are not reviewed ground truth.
Numerical template spellings are lexical evidence, not AST-verified or hardware-exact Vitis semantics. No target, objective, QoR or pragma configuration enters generation.

## Release gates

{
  "A": "pass",
  "B": "pass_native_occurrence_checks_and_adversarial_fixtures",
  "C": "pending_independent_fixture_and_stratified_review",
  "D": "pass",
  "E": "partial_unrelated_recovery_draft_failures"
}

No GNN encoder, training, LLM inference, HLS synthesis or refinement behavior changed. V2.1 remains the frozen baseline; this candidate is not labeled final.
