# RC3 regression report

{
  "completed_resume": {
    "builder_source_toolchain_mismatches_still_rejected": true,
    "canonical_files_rewritten": 0,
    "exit_status": 0,
    "native_generation_calls": 0,
    "snapshots_authenticated": 63
  },
  "full_worktree_suite_partitioned": {
    "all_ten_test_modules_included": true,
    "failed": 0,
    "passed": 267,
    "skipped": 0
  },
  "human_adjudication": false,
  "mandatory_worktree_regressions": {
    "command": "python -B -m pytest -q -p no:cacheprovider tests/test_mlir_graph_v2.py tests/test_structural_audit.py tests/test_v21_refinement.py tests/test_directive_domains.py --tb=short",
    "failed": 0,
    "log_sha256": "f35fd41af59590e235338d608ee661315f4dcb98680f1df51b8865d2811acb9e",
    "passed": 124
  },
  "native_extension_regressions": {
    "command": "PYTHONPATH=/home/elvouvali/tools/Polygeist/build-mailohls-assertions/tools/mlir/python_packages/mlir_core /home/elvouvali/.mlir-python311/bin/python -B /home/elvouvali/tools/Polygeist/python/test_mailohls_analysis.py",
    "log_sha256": "ef966f9e863318c706a1956130818f4a0dd5fa27321ae02ea6f1d5863147b92b",
    "passed": true
  },
  "project_python": "/home/elvouvali/miniforge3/envs/mailohls-llm-v2/bin/python",
  "protected_artifacts": {
    "GNN_branch/build_structural_memory.py": {
      "sha256": "c67dc203f5eb0f8852496682894a10bfaa8dd63f53806a7872c69e698747ba65",
      "unchanged_from_HEAD": true
    },
    "GNN_branch/mlir_data.py": {
      "sha256": "30562aa6aecae23bd91a3a4b4c87fa87da24f874005b76dac7b43f6deb2fb9b7",
      "unchanged_from_HEAD": true
    },
    "GNN_branch/mlir_graph_gen.py": {
      "sha256": "3111cf3fb09d363d6a89a6ec79ac043fc729ef3851aaa5980b5df45790e7397f",
      "unchanged_from_HEAD": true
    },
    "GNN_branch/model.py": {
      "sha256": "ace369a0db77e4975c7a2047ceb4fad17b2ec187142e8f1e99309639ca9f32c7",
      "unchanged_from_HEAD": true
    },
    "LLM_branch/common/structural_memory.py": {
      "sha256": "cd41a5c6d058740ae965bf3e9f606cde5fe07e09b7e8f898ca26498e7daccc62",
      "unchanged_from_HEAD": true
    },
    "LLM_branch/common/structural_xattn.py": {
      "sha256": "95b237b0527ab5e1c2a32ea0e3599ad3e3504f79bd9743e7ded2114e2e6b1041",
      "unchanged_from_HEAD": true
    },
    "branch_refs": {
      "HEAD": "4244ef7d4e95610d352c9258512587e9e5fefc5a",
      "llvm-ir": "0b5581b2b22becf1d20f476e22e92ea3fd533a64",
      "main": "57fa6fa362405c50001a9ed0c1026cf2d57ece3f",
      "mlir-target": "bf82c648273a5cd5eb30363059a3809e7b3979db"
    },
    "docs/graph-release-v21.json": {
      "sha256": "b04c22131c3eec41100f6aad7cc3faeb27434ee72babbeeeb3cdadf0decc591e",
      "unchanged_from_HEAD": true
    },
    "docs/graph-release-v21.sha256": {
      "sha256": "a5fc54c5ec17b43142efb159630df728c3bd64bf7102a773fffbd32193fb010c",
      "unchanged_from_HEAD": true
    },
    "docs/graph-release-v22.json": {
      "sha256": "b5f2b4216254c81d5afc8583ddb57925de9416ed14a2d95566cab150156d59c7",
      "unchanged_from_HEAD": true
    },
    "docs/graph-release-v22.sha256": {
      "sha256": "e07c58b56369c571496a101369ed69f1f70f09c08e6256db7f3b88b73050f805",
      "unchanged_from_HEAD": true
    },
    "experiments/refinement/__init__.py": {
      "sha256": "90a25fd816a70d7b450210e9e2af6f1f9de7238b85e338d2a5c86ec416f852c1",
      "unchanged_from_HEAD": true
    },
    "experiments/refinement/configurations.py": {
      "sha256": "4cf8791f025381c9b4ab9f53e7785a6925dd9e720110ffd95d2266d46faa89f8",
      "unchanged_from_HEAD": true
    },
    "experiments/refinement/experiment.py": {
      "sha256": "3de6f3c42a49a77d269b2e4ee9abf631fda0e7cb86b83130f1787b4333db8da0",
      "unchanged_from_HEAD": true
    },
    "experiments/refinement/relations.py": {
      "sha256": "353c438c4cc86c105fc3dbfdc42ba4c2688c4a17a036735ebfc6fde4788d7d59",
      "unchanged_from_HEAD": true
    },
    "experiments/refinement/synthesis.py": {
      "sha256": "084f663164b0e4b1d84aa6ed10abdd51e58e06a1c1c6d173dc0bae87bafc8eb7",
      "unchanged_from_HEAD": true
    },
    "experiments/refinement_search/__init__.py": {
      "sha256": "88eb59d3f441d85b7b23bcfbe434fb3b30b6ac0518fa13a8acf3d11c8d1fed27",
      "unchanged_from_HEAD": true
    },
    "experiments/refinement_search/benchmark.py": {
      "sha256": "55a6a61563d6823049b038d4537915bc372400cbe442b02fdea72b2365876df0",
      "unchanged_from_HEAD": true
    },
    "experiments/refinement_search/controller.py": {
      "sha256": "b3cb26432afe57a131a860eb4a9850c8f7cf715a08ffa4ebe6af3a9f2248a3db",
      "unchanged_from_HEAD": true
    },
    "experiments/refinement_search/policies.py": {
      "sha256": "e84b901b36d552634824ea063f5d2ec43f4b9a2a3d18da310a5e8333509010a2",
      "unchanged_from_HEAD": true
    }
  },
  "public_query_regression": {
    "lost_proven_relationships": 0,
    "new_possible_corpus_relationships": 0,
    "snapshots": 63,
    "source_native_run_and_release_graph_hashes_identical": true
  },
  "recovery_worktree_dependencies": {
    "evaluation_set/chstone-jpeg/code_to_memory_outputs/meta/kernel_info.txt": "d162e372de1f03eecff8b21c1870f716fa4e6737f6ff5ca974418bb6eb61fd68",
    "evaluation_set/chstone-jpeg/kernel.c": "7b8d959c1cf4a6923bea880057744193db5f11c43a0b48391b91b9477e33b3aa",
    "evaluation_set/chstone-jpeg/kernel_info.txt": "d162e372de1f03eecff8b21c1870f716fa4e6737f6ff5ca974418bb6eb61fd68",
    "evaluation_set/chstone-jpeg/kernel_placeholders.c": "175979575ab9017beaf2de50e2e1cfa9fd76e0d90e910ea0ec344020a3f97539",
    "evaluation_set/gemv/code_to_memory_outputs/meta/gemv.c": "c6e8b0aab3919a433803bacf29c7af6b56a6a5cb4d7a511a6875a21593a7e8f6",
    "evaluation_set/gemv/code_to_memory_outputs/meta/kernel_info.txt": "72dcbe726d2066c34854ff1efe04fe6f2dba9d5b4f050104c0edbc9d607c487a",
    "evaluation_set/gemv/gemv.c": "2c4dc8e6ca2f2b1fa9ac5e261e8cef2db2bb03278e438dee6ffef6867f444f21",
    "evaluation_set/gemv/kernel_info.txt": "72dcbe726d2066c34854ff1efe04fe6f2dba9d5b4f050104c0edbc9d607c487a",
    "evaluation_set/rosetta-3d-rendering/ap_int.h": "60c80f1e089a2c68c40b99e2a40ea8c24e7dae6a320af5552d855c150d0af89d",
    "evaluation_set/rosetta-3d-rendering/code_to_memory_outputs/meta/kernel_info.txt": "75350c282f1ce5e47b40d1ac030e9977a8c4115c381010fb0d2849a6a8af22b5",
    "evaluation_set/rosetta-3d-rendering/kernel.cpp": "b29d67e5e90401fff70ce477d1135c25284f8e84662fcc4121e88cd9c52faee9",
    "evaluation_set/rosetta-3d-rendering/kernel_info.txt": "75350c282f1ce5e47b40d1ac030e9977a8c4115c381010fb0d2849a6a8af22b5",
    "evaluation_set/rosetta-3d-rendering/kernel_placeholders.cpp": "b410186635f119b5c64fc519e6c94b6e00336753d18f5d66a392b183aafb843c",
    "historical_original_JPEG_6863ce0.c": "7fb3e3e27c8d3d97d9881b0bacfc236edb7f19ad68d59dfb1a830434739e2e66"
  },
  "remaining_worktree_regressions": {
    "command": "python -B -m pytest -q -p no:cacheprovider tests/test_refinement.py tests/test_refinement_search.py tests/test_refinement_benchmark.py tests/test_device_adaptation.py tests/test_select_nondominated_salt.py --tb=short",
    "failed": 0,
    "log_sha256": "8daa7593602d429b8600da4af3c5468fcf679bdf9e808cebc9adf46dcb136717",
    "passed": 90
  },
  "resume_contract_regression": "initial Git receipts retained, builder/source/toolchain contract changes still rejected",
  "v22_native_fixture_tests": {
    "command": "python -B -m pytest -q -p no:cacheprovider tests/test_mlir_graph_v22.py --tb=short",
    "failed": 0,
    "log_sha256": "3ba6bd1a000d6387975e9fe65fdb708a6eef25eaf6b2bf5d40e0fdb51e20ffd6",
    "passed": 53
  }
}

JPEG: same-translation-unit wrapper respects static ReadBuf linkage; table names match the benchmark. Rosetta: V2.1 remains 11/12, explicitly selected RC3 restores the static z_buffer target from compiler declaration/global-root evidence. Neither recovery workload is added to the frozen 63.
