"""Read-only archive validation with bundled code; native MLIR is not needed."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import time

root=Path(sys.argv[1]).resolve()
sys.path.insert(0,str(root/'code'))
from GNN_branch import mlir_graph_v2 as v
from GNN_branch.action_point_relations import get_action_point_relations,action_point_views,get_loop_semantics
assert Path(v.__file__).resolve().is_relative_to(root/'code'),v.__file__
assert importlib.util.find_spec('mlir') is None,'Run with project Python, without native MLIR PYTHONPATH'
release=json.loads((root/'release.json').read_text())
for name,digest in release['files_sha256'].items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
records=json.loads((root/'validation.json').read_text())
assert len(records)==63
start=time.monotonic();rows=[]
for ident,r in records.items():
 g=v.read_graph(root/'canonical'/Path(r['canonical']).name)
 c=v.read_graph(root/'compact'/Path(r['compact']).name)
 assert g.graph['schema']==v.SCHEMA_V22 and g.graph['semantic_revision']=='rc3'
 v.validate(g);v.validate(c)
 assert v.graph_payload(g)==v.graph_payload(v.expand_compact(c))
 assert action_point_views(g)==action_point_views(c)
 first,second={},{}
 for _,a in g.nodes(data=True):
  if a.get('category')!='action_point':continue
  point=a['action_id']
  assert get_action_point_relations(g,point,'all',_access_cache=first)==get_action_point_relations(c,point,'all',_access_cache=second)
  if a['action_kind']=='loop':assert get_loop_semantics(g,point)==get_loop_semantics(c,point)
 rows.append({'snapshot_id':ident,'kernel':r['kernel'],'status':'pass'})
 print(r['kernel'],'PASS',flush=True)
receipt={'graphs':len(rows),'passed':len(rows),'failed':0,'runtime_seconds':time.monotonic()-start,'native_mlir_loaded':False,'rows':rows}
if len(sys.argv)>2:Path(sys.argv[2]).write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='rows'},sort_keys=True))
