# RC3 action-binding audit

One row per unresolved RC2 registration. Compiler object lists, exact attributes, SSA/root witnesses and raw-IR hashes are in `details/action_binding_audit.json`. No shape-only or shared-use-line mapping is accepted. No elimination is inferred.

| Kernel / snapshot | Action / declaration | RC3 disposition |
|---|---|---|
| rodinia-hotspot-3-unroll / 7c11a20afd22 | L1 line 21: `L1: float temp_top[PARA_FACTOR];` | unresolved; no exact surviving declaration/annotation target |
| rodinia-hotspot-3-unroll / 7c11a20afd22 | L2 line 22: `L2: float temp_left[PARA_FACTOR];` | unresolved; no exact surviving declaration/annotation target |
| rodinia-hotspot-3-unroll / 7c11a20afd22 | L3 line 23: `L3: float temp_right[PARA_FACTOR];` | unresolved; no exact surviving declaration/annotation target |
| rodinia-hotspot-3-unroll / 7c11a20afd22 | L4 line 24: `L4: float temp_bottom[PARA_FACTOR];` | unresolved; no exact surviving declaration/annotation target |
| rodinia-hotspot-3-unroll / 7c11a20afd22 | L6 line 26: `L6: float power_center[PARA_FACTOR];` | unresolved; no exact surviving declaration/annotation target |
| serrano-kalman-filter / 96b4d608969f | L7 line 63: `/*L7:*/		DTYPE k_arr[INTERNAL_BATCHES];` | unresolved; no exact surviving declaration/annotation target |
| serrano-kalman-filter / 96b4d608969f | L8 line 64: `/*L8:*/		DTYPE calc_temp_arr[INTERNAL_BATCHES];` | unresolved; no exact surviving declaration/annotation target |
| serrano-kalman-filter / b90908f83f76 | L7 line 63: `/*L7:*/		DTYPE k_arr[INTERNAL_BATCHES];` | unresolved; no exact surviving declaration/annotation target |
| serrano-kalman-filter / b90908f83f76 | L8 line 64: `/*L8:*/		DTYPE calc_temp_arr[INTERNAL_BATCHES];` | unresolved; no exact surviving declaration/annotation target |
| rodinia-hotspot-2-pipeline / c448680ca9be | L1 line 23: `L1: float temp_top[PARA_FACTOR];` | unresolved; no exact surviving declaration/annotation target |
| rodinia-hotspot-2-pipeline / c448680ca9be | L2 line 24: `L2: float temp_left[PARA_FACTOR];` | unresolved; no exact surviving declaration/annotation target |
| rodinia-hotspot-2-pipeline / c448680ca9be | L3 line 25: `L3: float temp_right[PARA_FACTOR];` | unresolved; no exact surviving declaration/annotation target |
| rodinia-hotspot-2-pipeline / c448680ca9be | L4 line 26: `L4: float temp_bottom[PARA_FACTOR];` | unresolved; no exact surviving declaration/annotation target |
| rodinia-hotspot-2-pipeline / c448680ca9be | L6 line 28: `L6: float power_center[PARA_FACTOR];` | unresolved; no exact surviving declaration/annotation target |

Frozen lowering does not retain an independently identifiable allocation for these declarations. Surviving scalar calculations are not allocation identity or proof of elimination. A future frontend action-preservation experiment must use separate compilation provenance.
