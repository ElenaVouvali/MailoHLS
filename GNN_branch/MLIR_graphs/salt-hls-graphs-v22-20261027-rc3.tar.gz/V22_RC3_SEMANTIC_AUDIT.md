# V2.2 RC3 semantic audit

V2.2 RC3 — independent evidence or regressions remain outstanding

63/63 snapshots passed mechanical checks; 0 failed; 0 pending.

## Aggregate comparison

| Property | Frozen V2.1 | V2.2 |
|---|---:|---:|
| nodes | 30874 | 30634 |
| edges | 115316 | 115783 |
| registered | 606 | 606 |
| active | 604 | 592 |
| unresolved_registrations | 2 | 14 |
| source_only | 13 | 13 |
| access_status | {'proven': 2813, 'not_established': 182} | {'proven': 2973, 'not_established': 6, 'possible': 32} |
| dependence_status | {'possible': 51659, 'proven': 1911} | {'possible': 51659, 'proven': 1911} |
| dependence_reasons | {'aliased_storage_not_canonicalized': 25454, 'non_affine_access': 6173, 'affine_analysis_failure': 20032} | {'aliased_storage_not_canonicalized': 25454, 'non_affine_access': 6173, 'affine_analysis_failure': 20032} |
| native_negative_conclusions | 150439 | 150439 |
| duplicate_native_queries | 0 | 0 |
| cfg_successors | 0 | 43 |

## Findings and limits

External Kalman L7 has no unique source-bound storage target. L8 was mapped onto the native L6 allocation by shared use lines; V2.2 rejects that mapping. Surviving scalar computations do not prove a separate allocation or compiler elimination.
LLVM GEP/cast/memref-pointer chains retain their base storage and exact index operands. Pointer loads requiring reaching-store/call-context analysis remain uncertain. A root does not establish element overlap.
Pinned Python lacks Operation.successors. V2.2 uses mlirOperationGetSuccessor and checks native CFG occurrences independently.
All native dependence records, positive edges, uncertain edges and negative conclusions are preserved. AES uncertainty is not deduplicated or sampled away. The native analyzer stops at the first successful dependence depth; additional carrying loops remain unverified.
details/ contains comprehensive dependence classifications, root diagnostics, unresolved registrations and deterministic two-per-stratum draft review records. These drafts are not reviewed ground truth.
Numerical template spellings are lexical evidence, not AST-verified or hardware-exact Vitis semantics. No target, objective, QoR or pragma configuration enters generation.

## Release gates

{
  "A": "pass",
  "B": "pass_native_occurrence_checks_and_adversarial_fixtures",
  "C": "pending_independent_human_adjudication_of_real_program_worksheets",
  "D": "pass",
  "E": "pass_regressions_and_protected_artifact_hashes"
}

No GNN encoder, training, LLM inference, HLS synthesis or refinement behavior changed. V2.1 remains the frozen baseline; this candidate is not labeled final.

## RC2 versus RC3

{
  "RC2": {
    "active": 592,
    "cfg_successors": 43,
    "distinct_access_pairs": 204009,
    "duplicate_native_queries": 0,
    "edges": 115783,
    "native_negative_conclusions": 150439,
    "nodes": 30634,
    "registered": 606,
    "source_only": 13,
    "unresolved_registrations": 14,
    "access_status": {
      "proven": 2973,
      "not_established": 6,
      "possible": 32
    },
    "alias_kinds": {
      "may_alias": 1248,
      "must_alias": 548,
      "no_alias": 765
    },
    "dependence_reasons": {
      "aliased_storage_not_canonicalized": 25454,
      "non_affine_access": 6173,
      "affine_analysis_failure": 20032
    },
    "dependence_status": {
      "possible": 51659,
      "proven": 1911
    },
    "native_dependence_outcomes": {
      "dependence": 1911,
      "no_dependence": 55173,
      "not_applicable": 101439,
      "unknown": 45486
    },
    "native_dependence_reasons": {
      "aliased_storage_not_canonicalized": 25454,
      "proven_affine_dependence": 1911,
      "proven_affine_independence": 55173,
      "proven_no_alias": 95266,
      "non_affine_access": 6173,
      "affine_analysis_failure": 20032
    },
    "relation_types": {
      "actual_to_formal": 981,
      "alias": 2561,
      "analysis_summary": 1788,
      "calls": 331,
      "contains_block": 1089,
      "contains_operation": 9730,
      "declares_argument": 1465,
      "defines": 6205,
      "depends_on": 53570,
      "feature": 7366,
      "literal": 582,
      "memory_access": 3011,
      "next_operation": 8365,
      "operand": 13712,
      "owns_region": 1074,
      "references": 757,
      "resolves_to": 1893,
      "returns_to": 119,
      "targets": 592,
      "loop_carried": 318,
      "loop_child": 231,
      "control_flow": 43
    }
  },
  "RC3": {
    "active": 592,
    "cfg_successors": 43,
    "distinct_access_pairs": 204009,
    "duplicate_native_queries": 0,
    "edges": 115783,
    "native_negative_conclusions": 150439,
    "nodes": 30634,
    "registered": 606,
    "source_only": 13,
    "unresolved_registrations": 14,
    "access_status": {
      "proven": 2973,
      "not_established": 6,
      "possible": 32
    },
    "alias_kinds": {
      "may_alias": 1248,
      "must_alias": 548,
      "no_alias": 765
    },
    "dependence_reasons": {
      "aliased_storage_not_canonicalized": 25454,
      "non_affine_access": 6173,
      "affine_analysis_failure": 20032
    },
    "dependence_status": {
      "possible": 51659,
      "proven": 1911
    },
    "native_dependence_outcomes": {
      "dependence": 1911,
      "no_dependence": 55173,
      "not_applicable": 101439,
      "unknown": 45486
    },
    "native_dependence_reasons": {
      "aliased_storage_not_canonicalized": 25454,
      "proven_affine_dependence": 1911,
      "proven_affine_independence": 55173,
      "proven_no_alias": 95266,
      "non_affine_access": 6173,
      "affine_analysis_failure": 20032
    },
    "relation_types": {
      "actual_to_formal": 981,
      "alias": 2561,
      "analysis_summary": 1788,
      "calls": 331,
      "contains_block": 1089,
      "contains_operation": 9730,
      "declares_argument": 1465,
      "defines": 6205,
      "depends_on": 53570,
      "feature": 7366,
      "literal": 582,
      "memory_access": 3011,
      "next_operation": 8365,
      "operand": 13712,
      "owns_region": 1074,
      "references": 757,
      "resolves_to": 1893,
      "returns_to": 119,
      "targets": 592,
      "loop_carried": 318,
      "loop_child": 231,
      "control_flow": 43
    }
  }
}

## Evidence levels

All supported native occurrences are mechanically cross-checked. Native-parsed handwritten IR has independently specified assertions; compiled C++ fixtures and real frozen IR provide complementary evidence. No record has human adjudication. The deterministic stratified worksheets remain pending independent review, so Gate C stays open. No publication precision/recall or exhaustive memory proof is claimed.

## AES

{
  "uncertainty": {
    "affine_analysis_failure": 20032,
    "aliased_storage_not_canonicalized": 23124,
    "non_affine_access": 80
  },
  "affine_failures": 20032,
  "no_common_affine_scope_block": 20032,
  "reference": "pinned AffineAnalysis.cpp getCommonBlockInAffineScope 322-353 and dependence checker 621-624",
  "proof_boundary": "mechanical precondition localization, not an exact native failure-site receipt; unknown is not no-dependence",
  "native_depth_limit": "first successful dependence depth only; all records and distinct RAW/WAR/WAW preserved"
}
