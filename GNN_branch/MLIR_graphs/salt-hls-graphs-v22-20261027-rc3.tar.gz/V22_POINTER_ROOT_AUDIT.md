# RC3 pointer-root audit

The six original unresolved occurrences are traced in `details/pointer_root_audit.json`. Each concrete access remains represented. A formal pointer-containing cell has no complete local reaching-store set. Resolving its contents requires invocation-aware memory-state analysis; an actual/formal pointer binding alone does not prove what its contents hold.

| Snapshot | Access | RC3 root statuses |
|---|---|---|
| 41c8975cabb3 | op:_ZN7ap_uintILi256EE11range_proxyaSEm:op1 (write) | not_established |
| 41c8975cabb3 | op:_ZNK7ap_uintILi256EE11range_proxycvmEv:op1 (read) | not_established |
| 96b4d608969f | op:_ZN7ap_uintILi256EE11range_proxyaSEm:op1 (write) | not_established |
| 96b4d608969f | op:_ZNK7ap_uintILi256EE11range_proxycvmEv:op1 (read) | not_established |
| b90908f83f76 | op:_ZN7ap_uintILi256EE11range_proxyaSEm:op1 (write) | not_established |
| b90908f83f76 | op:_ZNK7ap_uintILi256EE11range_proxycvmEv:op1 (read) | not_established |

Supported new analysis: nonescaping allocation-local exact-address pointer cells, same native block order and complete structured conditional branches. Overwritten stores are handled. Helper escape, uncertain aliases and unsupported CFG paths keep the set incomplete. This is not a general reaching-definition or pointer-analysis engine.
