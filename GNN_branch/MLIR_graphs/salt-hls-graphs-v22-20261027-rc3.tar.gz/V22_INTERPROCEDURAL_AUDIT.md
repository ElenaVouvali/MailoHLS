# RC3 interprocedural audit

`details/interprocedural_audit.json` retains concrete operation, root, access mode, invocation chain and exact binding witnesses for every derived through-call action relationship. Possible alternatives are substituted lazily per used formal, never as a Cartesian product of all arguments. Candidate-set completeness is separate from certainty of any one root.

Native adversarial fixtures cover unique and ambiguous caller roots, incomplete branches, nested helpers, separate/repeated calls, return alternatives, recursion, external calls and helper-written pointer cells. Distinct caller arrays stay distinct. LUD L2–L5 is verified only in its exact `lud_diagonal:op5` invocation; the empty helper context does not inherit caller roots. Exact test results are in the regression receipt. This is representative validation, not exhaustive interprocedural proof.

Previously generated RC2 graphs have no `semantic_revision=rc3` marker and retain historical query behavior. New RC3 graphs opt into set-valued substitutions; canonical facts are not rewritten to make query joins easier.
